
	<div class="footer">
		<p>Copyright &copy; 2023 Uscew - <a style="color: white;text-decoration: none;">developed by yigithan&eren</a> | <a style="color: white;text-decoration: none;" href="../index.php">Anasayfa</a></p>
	</div>
</div>
	<?php if (isset($_SESSION["admin"])) { ?>
<a href="logout.php" class="float" target="_blank">
<i class="fa fa-sign-out my-float"></i>
</a><?php
}; ?>
</body>
</html>