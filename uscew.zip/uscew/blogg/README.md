
# Simple-PHP-Blog-Script

=== Simple-PHP-Blog-Script ===

Contributors: Adeleye Ayodeji
Tags: Blog
Author URI: https://adeleyeayodeji.com/
Author: Adeleye Ayodeji
Requires PHP: 5.6
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Simple-PHP-Blog-Script

== Description ==

= Create, delete, update and edit post content with PHP and MSQLI =

== Installation ==

1. Upload `Simple-PHP-Blog-Script` directory to the `/public html/` directory
2. Create a database named `blog` 
3. Import the tables located at `include\blog.sql` directory.
3. Run the script from the front end and everything works.
4. Admin url: `admin/index.php`
4. Admin details: Username: `admin` Password: `admin`

== Frequently Asked Questions ==

none

== Changelog ==

= 1.00 =
Initial release.

== Upgrade Notice ==

= 1.00 =
Initial release.
