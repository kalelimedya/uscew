<hr>
			<div class="more">
				<h3 style="margin-top: 0px;padding-top: 0px;font-family: calibri;">Related Post</h3>
				<img style="height: 150px;" src="image/Bishop-Oyedepo-Speaks.jpg"> <img style="height: 150px;" src="image/Bishop-Oyedepo-Speaks.jpg"> <img style="height: 150px;" src="image/Bishop-Oyedepo-Speaks.jpg"><p style="font-family: calibri; " align="center"><a style="background: blueviolet;padding: 5px;color: white;text-decoration: none;" href="#">More Post</a></p>
			</div> 
		</div>
	</div>
	<hr>