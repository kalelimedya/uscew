<?php
$localhost = "localhost";
$username = "root";
$password = "";
$database = "bloguscew";

$con = mysqli_connect($localhost, $username, $password, $database) or die();

?>